package com.java.searchElement;

class CheckListItem{

	private String item;
	private boolean selected;

	public CheckListItem(String item) {
		this.item = item;
	}

	public Object getItem() {
		return item;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean isSelected) {
		this.selected = isSelected;
	}

	@Override
	public String toString() {
		return item.toString();
	}
}