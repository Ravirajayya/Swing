package com.java.searchElement;

import java.awt.Component;

import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

@SuppressWarnings("rawtypes")
class CheckBoxListRenderer extends JCheckBox implements ListCellRenderer {

	private static final long serialVersionUID = 2480148171486382771L;

	public Component getListCellRendererComponent(JList comp, Object value, int index, boolean isSelected,
			boolean hasFocus) {
		
		setEnabled(comp.isEnabled());
		setSelected(((CheckListItem) value).isSelected());
		setFont(comp.getFont());
		setText(value.toString());
		
		if (isSelected) {
			setBackground(comp.getSelectionBackground());
			setForeground(comp.getSelectionForeground());
			
		} else {
			setBackground(comp.getBackground());
			setForeground(comp.getForeground());
		}

		return this;
	}
}