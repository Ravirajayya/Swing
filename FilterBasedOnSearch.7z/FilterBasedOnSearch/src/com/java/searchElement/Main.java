package com.java.searchElement;

import java.util.ArrayList;

import javax.swing.SwingUtilities;

public class Main {

	private static ArrayList<String> strItems;

	static {

		strItems = new ArrayList<String>();
		strItems.add("Analog1");
		strItems.add("Analog2");
		strItems.add("Analog3");
		strItems.add("Digital1");
		strItems.add("Digital2");
		strItems.add("AWT");
		strItems.add("KWT");
	}

	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new DynamicListDemo(strItems);
			}
		});
	}
}
