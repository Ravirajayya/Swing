package com.java.searchElement;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class DynamicListDemo {

	private JFrame frame;
	private ArrayList<CheckListItem> defaultValues;
	private JList<CheckListItem> jlist;

	@SuppressWarnings("unchecked")
	public DynamicListDemo(ArrayList<String> strItems) {

		defaultValues = loadChecklistItems(strItems);

		jlist = new JList<CheckListItem>(createDefaultList()) {

			private static final long serialVersionUID = 1L;

			public String getToolTipText(MouseEvent me) {
				int index = locationToIndex(me.getPoint());
				if (index > -1) {
					String item = jlist.getModel().getElementAt(index).getItem().toString().toLowerCase();
					return "Tooltip text for " + item;
				}
				return null;
			}
		};

		jlist.setCellRenderer(new CheckBoxListRenderer());
		jlist.setVisibleRowCount(5);
		jlist.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent event) {

				if (!SwingUtilities.isRightMouseButton(event)) {
					
					selectItem(event.getPoint());
					
				} else {

					jlist.setSelectedIndex(jlist.locationToIndex(event.getPoint()));

					JPopupMenu menu = new JPopupMenu();
					JMenuItem add = new JMenuItem("Add");
					JMenuItem clear = new JMenuItem("Clear");

					add.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {

							ArrayList<CheckListItem> mySelectedItems = new ArrayList<CheckListItem>();

							for (CheckListItem currCheckListItem : defaultValues) {

								if (currCheckListItem.isSelected()) {
									mySelectedItems.add(currCheckListItem);
									System.out.println(currCheckListItem.getItem().toString());
								}
							}
						}
					});
					
					clear.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {

							for (CheckListItem currCheckListItem : defaultValues) {

								if (currCheckListItem.isSelected()) {
									currCheckListItem.setSelected(false);
									jlist.repaint();
								}
							}
						}
					});

					menu.add(add);
					menu.add(clear);
					menu.show(jlist, event.getPoint().x, event.getPoint().y);
				}
			}
		});

		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(new JScrollPane(jlist));
		frame.add(createTextField(new JTextField(15)), BorderLayout.PAGE_START);
		frame.pack();
		frame.setTitle("Signal Selection Window");
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.getContentPane().getComponent(0).setVisible(false);
	}

	private ArrayList<CheckListItem> loadChecklistItems(ArrayList<String> strItems) {

		defaultValues = new ArrayList<CheckListItem>();

		for (String currItem : strItems) {
			defaultValues.add(new CheckListItem(currItem));
		}

		return defaultValues;
	}

	private DefaultListModel<CheckListItem> createDefaultList() {

		DefaultListModel<CheckListItem> items = new DefaultListModel<>();
		for (CheckListItem currCheckListItem : defaultValues) {
			items.addElement(currCheckListItem);
		}

		return items;
	}

	private JTextField createTextField(JTextField textField) {
		textField.getDocument().addDocumentListener(new DocumentListener() {

			@Override
			public void insertUpdate(DocumentEvent e) {
				filter();
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				filter();
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
			}

			private void filter() {
				String filter = textField.getText().toLowerCase();
				filterModel((DefaultListModel<CheckListItem>) jlist.getModel(), filter);
			}

		});

		return textField;
	}

	protected void filterModel(DefaultListModel<CheckListItem> listModel, String filter) {

		if (!filter.isEmpty()) {
			frame.getContentPane().getComponent(0).setVisible(true);
		} else {
			frame.getContentPane().getComponent(0).setVisible(false);
		}

		for (CheckListItem currCheckListItem : defaultValues) {

			String currDeafultVal = currCheckListItem.getItem().toString().toLowerCase();

			if (!currDeafultVal.toLowerCase().contains(filter)) {
				if (listModel.toString().toLowerCase().contains(currDeafultVal)) {
					listModel.removeElement(currCheckListItem);
				}
			} else {
				if (!listModel.toString().toLowerCase().contains(currDeafultVal)) {
					listModel.addElement(currCheckListItem);
				}
			}
		}
	}

	private void selectItem(Point point) {
		int index = jlist.locationToIndex(point);

		if (index >= 0) {
			CheckListItem item = jlist.getModel().getElementAt(index);
			item.setSelected(!item.isSelected());
			jlist.repaint(jlist.getCellBounds(index, index));
		}
	}
}